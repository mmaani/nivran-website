import { Pool, QueryResult, QueryResultRow } from "pg";

declare global {
  // eslint-disable-next-line no-var
  var __nivranPool: Pool | undefined;
}

function getPool(): Pool {
  const cs = process.env.DATABASE_URL;
  if (!cs) throw new Error("Missing DATABASE_URL");

  if (!global.__nivranPool) {
    global.__nivranPool = new Pool({
      connectionString: cs,
      ssl: cs.includes("localhost") ? undefined : { rejectUnauthorized: false },
    });
  }
  return global.__nivranPool;
}

type DB = {
  (): Pool;
  query<T extends QueryResultRow = any>(
    text: string,
    params?: any[]
  ): Promise<QueryResult<T>>;
};

// db() -> Pool
// db.query(...) -> convenience wrapper
export const db: DB = Object.assign(
  (() => getPool()) as any,
  {
    query: <T extends QueryResultRow = any>(text: string, params?: any[]) =>
      getPool().query<T>(text, params),
  }
);
