import CheckoutClient from "./CheckoutClient";

export default function Page() {
  return <CheckoutClient />;
}
